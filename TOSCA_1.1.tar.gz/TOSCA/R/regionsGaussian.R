
regionsGaussian <- function(Data, cutoff=0.001, Coord=coord, verbose=TRUE)
{
				
	if(mean(Data$MovAverage, na.rm=TRUE) < median(Data$MovAverage, na.rm=TRUE))
    {stop("Impossible to run this method with this distribution, because the mean is higher than the median of the variable. This methods requires asy;etry with a positive tail")
	}
	
	if(verbose)print("Detection of Enrichment by the Gaussian method")
	
	## Catching the most frequent value (the "mode") of the distribution (as the peak of the histogram)
	b <- NULL
	s <- seq(50,500,20)
	for(j in 1:length(s))
	{
		h <- hist(Data$MovAverage, br=seq(min(Data$MovAverage, na.rm=TRUE), max(Data$MovAverage, na.rm=TRUE), length=s[j]), plot=FALSE)
		b[j] <- h$breaks[which.max(h$counts)]
	}

	m <- which(Data$MovAverage < mean(b))
	a <- c(Data$MovAverage[m],2*mean(b)-Data$MovAverage[m])
	ks <- ks.test(a,"rnorm")
	if(ks$p.value > 10e-4)
	{
		stop(paste("The left part of the distribution appear not to be gaussian","\n Kolmogorov-Smirnov p.value=", ks$p.value,"\n")) 
	}
	
	Data$Pval <- pnorm(Data$MovAverage, mean(a), sd(a), lower.tail=FALSE)
	threshold <- min(Data$MovAverage[which(Data$Pval < cutoff)], na.rm=TRUE)
	if(verbose)print(paste("Gaussian method finds a threshold of",signif(threshold,4)))
	Data <- defRegions(Data, threshold, Coord, rand=FALSE)
	if(verbose)print(paste("Gaussian method detects",length(which(Data$RegionPeak==1)),"regions"))		
	return(Data)
}
