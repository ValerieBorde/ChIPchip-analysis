## For the normal values, find the enriched regions and returns a data frame with the Regions, the Max Value of each regions and the size of the regions.
## For the randomized values, simply returns the number of regions.

defRegions <- function(Data, threshold, Coord=coord, rand=FALSE, j=0)
{

pi=NULL
k=1
for(i in unique(Coord$Chromosome[which(!is.na(Coord$Chromosome))]))
{
m=which(Coord$Chromosome == i)
if(length(m)>0){
p=sort(Coord$Position[m],index.return=TRUE)
pi=c(pi,m[p$ix])
}
}
	vector=rep(NA,length(Coord[,1]))
    if(rand == FALSE) vector[which(!is.na(pi))] <- Data$MovAverage[pi[which(!is.na(Coord$Chromosome))]]    
    if(rand == TRUE) vector[which(!is.na(pi))] <- Data[pi[which(!is.na(Coord$Chromosome))],j]
	
    lpval <- length(vector)
    Enriched <- which(vector>threshold)

    region <- NULL
    Break <- which((Enriched[2:lpval]-Enriched[1:(lpval-1)])!=1)

    ## True for the highest value of the region
    Peak <- rep(0, lpval)

    ## True for all elements included in a region
    Region <- rep(0, lpval)

    ## Size of the regions, indicated for each elements of the region
    RegionSize <- rep(0, lpval)

    Data$RegionRank <- rep(NA, lpval)
    Data$RegionPeak <- rep(NA, lpval)
    Data$RegionSize <- rep(NA, lpval)
    Data$Region <- rep(NA, lpval)

    if(length(Break) > 0)
	{
        Thisregion <- Enriched[1:Break[1]]
        wmax=which(vector[Thisregion]==max(vector[Thisregion],na.rm=TRUE))
        if(length(wmax)>1)wmax=wmax[as.integer((1+length(wmax)/2))]
        Peak[region[wmax]] <- 1
        Region[Thisregion] <- 1
        RegionSize[Thisregion] <- length(Thisregion)

        if(length(Break) > 1)
          {
            for(i in 2:length(Break))
			{
                Thisregion <- Enriched[(Break[i-1]+1):Break[i]]
                wmax=which(vector[Thisregion]==max(vector[Thisregion],na.rm=TRUE))
                if(length(wmax)>1)wmax=wmax[as.integer((1+length(wmax))/2)]
                Peak[Thisregion[wmax]] <- 1
                Region[Thisregion] <- i
                RegionSize[Thisregion] <- length(Thisregion)
            }
        }
    }

    if(rand == FALSE)
	{
        Data$RegionPeak[pi[which(!is.na(Coord$Chromosome))][which(Peak==1)]] <- Peak[which(Peak==1)]
        Data$Region[pi[which(!is.na(Coord$Chromosome))][which(Region==1)]] <- Region[which(Region==1)]
        Data$RegionSize[pi[which(!is.na(Coord$Chromosome))][which(RegionSize>0)]] <- RegionSize[which(RegionSize>0)]
        
        Data$RegionRank[which(Data$RegionPeak == 1)] <- length(which(Data$RegionPeak == 1)) - rank(Data$MovAverage[which(Data$RegionPeak == 1)],ties.method="min")+1
        return(Data)
    }
    if(rand == TRUE)return(length(which(Peak == 1)))
}
