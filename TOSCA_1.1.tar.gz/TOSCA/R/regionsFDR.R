


## Define enriched regions:
## Smooth the logratio with a sliding window of parameters size and step
## Then for nbPerm permutations, do:
##   permute the logratio (with the sample function)
##   smooth the logratio
##   store the smoothed vector in a matrix
##   Use this matrix to define the best threshold, in order to get the ExpectedFDR

## setThreshold FDR
## use the randomized values to compute the average number of false positives, and return the threshold corresponding to the expected FDR. This threshold has to be in the last quartile of the smoothed distribution. The FDR is accepted when not more the 0.01 different from the expected FDR.

setThresholdFDR <- function(Data, MovAverageRand, ExpectedFDR, Coord=coord, verbose=TRUE)
{
	a <- b <- NULL
	
	q <- quantile(Data$MovAverage, na.rm=TRUE)
	
	NbPerm <- dim(MovAverageRand)[2]
	min <- q[[3]]
	max <- q[[5]]
	FDR <- 1
	while(abs(FDR-ExpectedFDR)>0.01)
	{
		FPos <- NULL
		threshold <- (min + max)/2  
		Pos <- defRegions(Data, threshold, Coord, rand=FALSE)  
		a <- length(which(Pos$RegionPeak == 1))
		while(a == 0)
		{
		threshold <- (threshold + min)/2
		Pos <- defRegions(Data, threshold, Coord, rand=FALSE)  
		a <- length(which(Pos$RegionPeak == 1))
		}
		for(j in 1:NbPerm){FPos[j] <- defRegions(MovAverageRand, threshold, Coord, rand=TRUE, j)}
		
		b <- mean(FPos, na.rm=TRUE)
		if(b/a == FDR){cat("Unable to find a threshold\n"); break}
		FDR <- b/a
		if(verbose)cat("At threshold:",threshold, "# False Pos:", b, "# Pos:", a, "FDR=", FDR, "\n",sep=" ")
			if(FDR > ExpectedFDR)min <- threshold
			if(FDR < ExpectedFDR)max <- threshold
					
	}
			
			return(threshold)
			
}

## regions FDR
regionsFDR <- function(Data, variable="LRMC", ExpectedFDR=0.1, nbPerm=30, Coord=coord, verbose=TRUE)
{
#	if(verbose)print("Detection of Enrichement by the FDR method")
	Dat <- Data[[variable]]
	DatRand <- matrix(nrow=length(Dat), ncol=nbPerm)
	MovAverageRand <- matrix(nrow=length(Data$MovAverage), ncol=nbPerm)
	for(i in 1:nbPerm)
	{
          if(length(which(is.na(Dat)))>0)DatRand[-which(is.na(Dat)),i] <- sample(Dat[-which(is.na(Dat))])
          else DatRand[,i]=sample(Dat)
          MovAverageRand[,i] <- as.numeric(lapply(Data$GridProbe,  function(index, vector) mean(vector[index], na.rm=TRUE)
, DatRand[,i]))
	}
	MovAverageRand=as.data.frame(MovAverageRand)
	
	## Find the best threshold between the third and the last quartile of the distribution.
	threshold <- setThresholdFDR(Data, MovAverageRand, ExpectedFDR, Coord)
	
#	if(verbose)print(paste("FDR method finds a threshold of",signif(threshold,4)))
	
	Data <- defRegions(Data, threshold, Coord, rand=FALSE)
#	if(verbose)print(paste("FDR method detects",length(which(Data$RegionPeak==1)),"regions"))	

		
    return(Data)
}
