## compute for each probe, or only for a subset of probes, 
## the distance to the closest feature (all or only a subset of of the features present in the FeaturesTable).
## This features can be oriented (such as Genes Start Sites) or unoriented (such as Origin of Replication). In this case, the column Strand must be contain NA
## need as parameter a file containing the coordinates of the features
## FeaturesTable should contain Chromosome, Position and Strand



DistToFeatures <- function(FeaturesTable, subsetprobe=NULL, subsetFeatures="ALL", Coord=coord)
{
	if(is.null(FeaturesTable$Strand))stop(print("There is no column Strand in the Table"))
	if(length(subsetFeatures)==1){if(subsetFeatures == "ALL")subsetFeatures <- c(1:length(FeaturesTable[,1]))}
	
	myFunc <- function(probe)
	{
		p1 <- which.min(abs(FeaturesTable$Position[which(FeaturesTable$Chromosome[subsetFeatures] == Coord$Chromosome[probe])] - Coord$Position[probe]))
		p <- subsetFeatures[which(FeaturesTable$Chromosome[subsetFeatures] == Coord$Chromosome[probe])[p1]]
		if(length(p)==1){
			if(FeaturesTable$Strand[p] == "-") return(FeaturesTable$Position[p] - Coord$Position[probe])
			if(FeaturesTable$Strand[p] == "+") return(Coord$Position[probe] - FeaturesTable$Position[p])
			else return(abs(Coord$Position[probe] - FeaturesTable$Position[p]))
		}
	}

	DistFeatures <- rep(NA,length(Coord$Position))	
	if(is.null(subsetprobe)) DistFeatures[which(!is.na(Coord$Position))] <- apply(as.data.frame(which(!is.na(Coord$Position))),1,myFunc)
		else DistFeatures[subsetprobe] <-apply(as.data.frame(subsetprobe),1,myFunc)
	return(DistFeatures)
}
