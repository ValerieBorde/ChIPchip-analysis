# Signals are lists composed of two elements: the signal or values ($s), and the degree ($d).

##########################################################################################
# Importation of filter coefficients
##########################################################################################

importfilter <- function (filter,degree)
{
	if (filter=="Daubechies")
		reper=paste("Daub",degree*2,sep="")
	if (filter=="Symlets")
		reper=paste("Syml",degree*2,sep="")
	h=read.table(paste("Signal Processing/Other files/Filters/",filter,"/",reper,"/h",sep=""),strip.white=TRUE)
	g=read.table(paste("Signal Processing/Other files/Filters/",filter,"/",reper,"/g",sep=""),strip.white=TRUE)
	rh=read.table(paste("Signal Processing/Other files/Filters/",filter,"/",reper,"/rh",sep=""),strip.white=TRUE)
	rg=read.table(paste("Signal Processing/Other files/Filters/",filter,"/",reper,"/rg",sep=""),strip.white=TRUE)
	d=length(h)-1
	f=list(h=list(s=t(h),d=d),g=list(s=t(g),d=d),rh=list(s=t(rh),d=0),rg=list(s=t(rg),d=0))
	return(f)
	}

##########################################################################################
# Personalized convolution
##########################################################################################

myconv <- function (x,f)
{
	d=x$d+f$d
	s=convolve(x$s,f$s,type="open")
	y=list(s=s,d=d)
	return(y)
	}

##########################################################################################
# Insertion of zeros in a signal
##########################################################################################

zeroins <- function (u,j)
{
	# j is the scale
	s=u$s
	for (i in (length(s)-1):1)
	{
		s=append(s,rep(0,2^j-1),after=i)
		}
	d=2^j*u$d
	y=list(s=s,d=d)
	return (y)
	}

##########################################################################################
# Summation of two Laurent series
##########################################################################################

addsignals<- function (u,v)
{
	y=list()
	# manage lowest degrees
	if (u$d<v$d)
	{
		y$d=v$d
		u$s=append(rep(0,v$d-u$d),u$s)
		}
	else
	{
		if (v$d<u$d)
		{
			y$d=u$d
			v$s=append(rep(0,u$d-v$d),v$s)
			}
		else
		{
			y$d=u$d
			}
		}
	
	# manage highest degrees
	if (length(u$s)<length(v$s))
	{
		u$s=append(u$s,rep(0,length(v$s)-length(u$s)))
		}
	else
	{
		if (length(v$s)<length(u$s))
		{
			v$s=append(v$s,rep(0,length(u$s)-length(v$s)))
			}
		}
	y$s=u$s+v$s
	return(y)
	}

# We're beginning wavelette routines

##########################################################################################
# Wavelette transform
##########################################################################################

WaveTransform <- function (u,h,g,scale)
{
	WT=list()
	WT$LoRes=u
	WT$Details=list()
	for (i in 1:scale)
	{
		WT$Details[[i]]=myconv(WT$LoRes,g)
		WT$LoRes=myconv(WT$LoRes,h)
		h=zeroins(h,1)
		g=zeroins(g,1)
		}
	return(WT)
	}

##########################################################################################
# Reconstruction
##########################################################################################

InvWaveTransform <- function (WT,rh,rg,scale)
{
	for (i in scale:1)
	{
		rrh=zeroins(rh,i-1)
		rrg=zeroins(rg,i-1)
		WT$LoRes=addsignals(myconv(WT$LoRes,rrh),myconv(WT$Details[[i]],rrg))
		WT$LoRes$s=WT$LoRes$s/2
		}
	s=WT$LoRes
	return(s)
	}

##########################################################################################
# Signal processing
##########################################################################################

WaveProcess <- function (signal,scale,thres,f,inferior)
{
	u=list()
	u$d=0
	u$s=signal
	
	WT=WaveTransform(u,f$h,f$g,scale)
	for (i in 1:scale)
	{
		sig=WT$Details[[i]]$s
		if (inferior)
		{
			WT$Details[[i]]$s=replace(sig,which(abs(sig)<thres),0)
			}
		else
		{
			WT$Details[[i]]$s=replace(sig,which(abs(sig)>thres),0)
			}
		}
	LR=InvWaveTransform(WT,f$rh,f$rg,scale)
	return (LR)
	}