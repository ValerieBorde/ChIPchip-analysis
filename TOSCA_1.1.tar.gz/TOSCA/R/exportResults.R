exportResults <- function(Data,variable="LRMC", Coord=coord, filename=NA)
{
	if(is.na(filename))filename <- "ResultsPeak"
		
	u=which(!is.na(Data$RegionRank))
	if(length(u)>0){
	u=u[sort(Data$RegionRank[u],index.return=TRUE)$ix]
	
	tabPeak=data.frame(Name=Coord$Name[u], Chromosome=Coord$Chromosome[u], PeakPosition=Data$RegionPeak[u], Rank=Data$RegionRank[u], LogRatio=Data[[variable]][u])
	
	write.table(tabPeak, file=paste(filename,".txt",sep=""), row.names=FALSE, quote=FALSE, sep="\t")
	}
	else print("No Peak to report...")
}

exportAll <- function(Data,variable="LRMC", Coord=coord, filename=NA)
{
	if(is.na(filename))filename <- "Data"
	tabAll=data.frame(Name=Coord$Name,  Chromosome=Coord$Chromosome, Position=Coord$Position, LogRatio=Data[[variable]], PeakRank=Data$RegionRank, PeakPosition=Data$RegionPeak)
	
	write.table(tabAll, file=paste(filename,"_All.txt",sep=""), row.names=FALSE, quote=FALSE, sep="\t")
}