setwd("") # Set the work directory

source("Signal Processing/Other files/Sources/SignalProcess.R")
source("Signal Processing/Other files/Sources/dodenoisewinManu.R")

coordfile="coord.txt" # Name of coord file (This file is in Common -> Coord file folder)
centrofile="PositionCentromere.txt" # Name of centromere positions table file (This file is in Common -> Coord file fodler)
Denoising=TRUE # Do you want to process with denoising ?
scale=4 # Scale of denoising (the greater it is, from further it will see)
thres=2.8 # Threshold for denoising process (the greater it is, the more rigorous you will be)
SuppPeaks=TRUE # Do you want to suppress isolated peaks?
superpose=FALSE # Do you want to superpose plots (RatioNorm and RatioSmooth)?
RecoverNA=FALSE # Do you want to recover NA probes? If FALSE, NA probes will be replaced by the mean of their extremities
type="h" # h for histogram and l for plot (for denoising pdf)
force_threshold=FALSE # Do you want to impose a threshold value ? (if FALSE, FindPeaks will use MeanMax(Array1,coord,threshold))
threshold=1.56 # thresholds for peaks is smooth>0
# (default value was 1.56)
threshold2=c(threshold/2,threshold,1500) # thresholds for peaks if there is no smoothing (first is relative height(difference bet max and the nearest minimum), second is absolute height, third is distance between two near peaks)
range=50 # number of barplots for distibution of peak distances
range2=200 # number of barplots for distribution of ratios
smooth=1 # How many times do you want to realize the smoothing?
movwin=2000 # Window size (bp) for smoothing

arrayfile=c("","") # Name of your GPR or table files to be processed (Drag your file in Common -> GPR files or Common -> Table files). If you enter two files, these will be considered as replicates and their ratios averaged. 
name="" # Name of table file saved and of directory with pdf files (if nothing is written, takes automatically the name_of_the_first_arrayfile_Processed")

Data=DataSignalProcess(coordfile,centrofile,arrayfile,scale,thres,SuppPeaks,superpose,RecoverNA,type,threshold,name,range,size,smooth,threshold2,range2,movwin,Denoising,force_threshold) # PDF files will be created in Saved files -> PDF files, and Table files in Saved files -> Processed table files
Array1=Data$Array1
coord=Data$coord