


reportQC <- function(data, variable="LRMC")
{
    m <- which(!is.na(data[[variable]]))

   if(!is.null(data$FBip) & !is.null(data$FBtotal))
   {
		nf <- layout(matrix(c(1:6), nc=2, byrow=TRUE))
		par(mai=c(0.3, 0.3, 0.4, 0.2))
		
		myBreak <- seq(min(c(data$FBip[m], data$FBtotal[m]), na.rm=TRUE), max(c(data$FBip[m], data$FBtotal[m]), na.rm=TRUE), length.out=1000)
		h <- hist(data$FBip[m], br=myBreak, plot=FALSE)
		h1 <- hist(data$FBtotal[m], br=myBreak, plot=FALSE)
		plot(h$mids, h$counts, type="l", col="red", ylim=c(0, max(c(h$counts, h1$counts), na.rm=TRUE)), main="colors histogram", xlab="", ylab="")
		lines(h1$mids, h1$counts, col="green")
		legend("topright", legend=c("FBip", "FBtotal"), col=c("red", "green"), lty=c(1, 1))
	
		plot(log2(data$FBip[m]), log2(data$FBtotal[m]), main="Intensities plot", xlab="Log2(FB635)", ylab="Log2(FB532)", pch=".")
		abline(0, 1, col="red", lwd=2)

		plot(log2(data$FBip[m]*data$FBtotal[m]), data[[variable]][m], main="MA Plot", xlab="log2(I_ip*I_total)", ylab="LogRatio", pch=".")
	}
	else
	{
		nf <- layout(matrix(c(1:4), nc=2, byrow=TRUE))
		par(mai=c(0.3, 0.3, 0.4, 0.2))
	}
	
    h <- hist(data[[variable]], br=100, main=paste(variable, "histogram"), xlab="", ylab="")
    hist(data[[variable]][which(!is.na(data$RegionRank))], br=h$breaks, add=TRUE, col="red")

    h <- hist(data$MovAverage, br=100, main="Sliding Window on norm. LogRatio", xlab="", ylab="")
    hist(data$MovAverage[which(data$AllRegLoc==1)], br=h$breaks, col="red", add=TRUE)
    legend("topleft", legend=paste(length(which(data$RegionPeak==1)), "Regions"))
 
	qqnorm(data$MovAverage)
}
