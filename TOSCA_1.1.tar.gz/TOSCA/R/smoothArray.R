
## Functions to compute a smoothing of the profile with a sliding window approach.
## First, run movWin with the size of the window in parameters, and then apply the resulting list to the ra profile. 

## Compute the list of probes to include at each step of the sliding window

movWin <- function(size, Coord=coord, verbose=TRUE)
{
    GridProbe <- NULL
	
    for(chro in unique(Coord$Chromosome))
	{
	 if(!is.na(chro)){
	 u=which(Coord$Chro==chro)
	 u=u[sort(Coord$Pos[u],index.return=TRUE)$ix]
	 
	 GridPlus=rep(0,length(u))
	 done=FALSE
	 i=1
	 while(done == FALSE)
		 {
			v=rep(NA,length(u))
			v=Coord$Pos[u[(i+1):length(u)]]-Coord$Pos[u[1:(length(u)-i)]]
			vv=which(v<=size/2)
			if(length(vv)>0)
			{
				GridPlus[vv]=i
				i=i+1
			}
			else done=TRUE
		}

	GridMinus=rep(0,length(u))
	done=FALSE
	 i=1
	 while(done == FALSE)
		 {
			v=rep(NA,length(u))
			v[(i+1):length(u)]=Coord$Pos[u[1:(length(u)-i)]]-Coord$Pos[u[(i+1):length(u)]]
			vv=which(v>=(-size/2))
			if(length(vv)>0)
			{
				GridMinus[vv]=i
				i=i+1
			}
			else done=TRUE
		}
	
	GridProbe[u]=apply(data.frame(c(1:length(u))),1, function(i) return(unique(c(u[i:(i+GridPlus[i])],u[(i-GridMinus[i]):i]))))
	if(verbose)cat(chro," smoothed!\n")
	}
	
	
	else {GridProbe[which(is.na(Coord$Chro))]=rep(NA,length(which(is.na(Coord$Chro)))) }
    }
	return(GridProbe)
}


## smoothArray
## Compute a smoothing of the profiles along the chromosomes. 
## For each probe, calculate the average of the adjacent probes within a distance of size/2 (total length of the window = size)
## Needs the list WinMov computed with movWin. Can be passed as parameter if it has already been computed.

smoothArray <- function(Array,variable="LRMC", Coord=coord, WinMov=NULL, size=1000, verbose=TRUE)
{
	if(is.null(WinMov)) Array$GridProbe <- movWin(size, Coord, verbose)
	if(!is.null(WinMov)) Array$GridProbe=WinMov	
	
	Array$MovAverage <- as.numeric(lapply(Array$GridProbe, function(index, vector) mean(vector[index], na.rm=TRUE), Array[[variable]]))
	Array$SizeParam <- size
	return(Array)
}
