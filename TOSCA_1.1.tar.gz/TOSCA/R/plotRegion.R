## plot a region on chromosome chro, around position pos.
## The size of the region is a parameter. If O, the entire chromosome is plotted
## Other parameters: pdf (should the region be plotted in a pdf file0
## probes: if true, probes are represented by small lines. If false, bars are used.

plotRegion <- function(Data, pos, chro, size=0, variable="LRMC", Coord=coord, probes=FALSE)
{
    if(size == 0)
    {
        m <- which(Coord$Chromosome == chro)
	m=m[sort(Coord$Position[m],index.return=TRUE)$ix]
        xlimMin <- 0
        xlimMax <- max(Coord$Position[m])
    }
    else 
    {
        m <- which(Coord$Chromosome == chro & abs(Coord$Position - pos) <= size/2)
	m=m[sort(Coord$Position[m],index.return=TRUE)$ix]
        xlimMin <- pos - size/2
        xlimMax <- pos + size/2
    }

   

	Peak <- Data$RegionPeak
	Rank <- Data$RegionRank
	
	ylimMax <- max(c(1,  Data[[variable]][m]), na.rm=TRUE)
    ylimMin <- min(c(-1, Data[[variable]][m]), na.rm=TRUE)

    if(length(m) < 50 | probes == TRUE)
    {
        plot(Coord$Position[m], Data$MovAverage[m], type="l", lwd=3, xlim=c(xlimMin,xlimMax), ylim=c(ylimMin,ylimMax*1.3), xlab=paste("Position on Chro",chro), ylab="LogRatio",main="", col="red")
        for(i in 1:length(m))
        {
            lines(c(Coord$Start[m[i]], Coord$End[m[i]]), rep(Data[[variable]][m[i]], 2), col="blue", lwd=3)
        }

        p <- which(Peak[m] == 1)
        if(length(p) > 0)
        {
            for(i in 1:length(p))
			{
				points(Coord$Position[m[p[i]]], ylimMax*1.1, pch=8, cex=1.5, col="black")
				if(length(p)<10)
				text(Coord$Position[m[p[i]]], ylimMax*1.1, labels=Rank[m[p[i]]], col="black",pos=c(1,3)[(i%%2)+1],offset=1)
			}	
        }
        abline(h=0, col="grey")
    }


    if(length(m) > 50 & probes == FALSE)
    {
        plot(Coord$Position[m], Data[[variable]][m],type="h", lwd=1, xlim=c(xlimMin,xlimMax), ylim=c(ylimMin,ylimMax*1.3), xlab=paste("Position on Chro",chro), ylab="LogRatio", main="", col="grey")

        lines(Coord$Position[m], Data$MovAverage[m], type="l", lwd=3, xlim=c(pos-size/2,pos+size/2), xlab=paste("Position on Chro",chro), ylab="LogRatio", main="", col="red")
        abline(h=0, col="grey")

        p <- which(Peak[m] == 1)
        if(length(p) > 0)
        {
            for(i in 1:length(p))
			{
				points(Coord$Position[m[p[i]]], ylimMax*1.1, pch=8, cex=1.5, col="black")
				if(length(p)<10)
				text(Coord$Position[m[p[i]]], ylimMax*1.1, labels=Rank[m[p[i]]], col="black",pos=c(1,3)[(i%%2)+1],offset=1)
			}	


        }
    }
}





