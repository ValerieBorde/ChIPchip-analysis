

## defRegionsMPR
## For the normal values, find the enriched regions and returns a data frame with the Regions, the Max Value of each regions and the size of the regions.

defRegionsMPR <- function(Data, threshold=0.9, nbProbe=3, Coord=coord)
{

pi=NULL
k=1
for(i in unique(Coord$Chromosome[which(!is.na(Coord$Chromosome))]))
{
m=which(Coord$Chromosome == i)
if(length(m)>0){
p=sort(Coord$Position[m],index.return=TRUE)
pi=c(pi,m[p$ix])
}
}
	vector=rep(NA,length(Coord[,1]))
	vector[which(!is.na(pi))] <- Data$MedianPR[pi[which(!is.na(Coord$Chromosome))]]    
    lpval <- length(vector)
	if(lpval<2)stop("Error with the vector MedianPR in Data")
    Enriched <- which(vector>threshold)

    region <- NULL
    Break <- which((Enriched[2:lpval]-Enriched[1:(lpval-1)])!=1)

    ## True for the highest value of the region
    AllMaxLoc <- rep(0, lpval)

    ## True for all elements included in a region
    AllRegLoc <- rep(0, lpval)

    ## Size of the regions, indicated for each elements of the region
    AllRegSize <- rep(0, lpval)

    
    if(length(Break) > 0)
	{
        region <- Enriched[1:Break[1]]
        if(length(region) > nbProbe)
		{
			AllMaxLoc[region[which.max(vector[region])]] <- 1
			AllRegLoc[region] <- 1
			AllRegSize[region] <- length(region)
		}
        if(length(Break) > 1)
		{
            for(i in 2:length(Break))
			{
                region <- Enriched[(Break[i-1]+1):Break[i]]
				if(length(region) > nbProbe)
				{
					AllMaxLoc[region[which.max(vector[region])]] <- 1
					AllRegLoc[region] <- i
					AllRegSize[region] <- length(region)
				}
            }
        }
    }
		
		Data$RegionPeak=Data$Region=Data$RegionSize=Data$RegionRank=rep(NA,lpval)
		Data$RegionPeak[pi[which(!is.na(Coord$Chromosome))][which(AllMaxLoc==1)]] <- AllMaxLoc[which(AllMaxLoc==1)]
        Data$Region[pi[which(!is.na(Coord$Chromosome))][which(AllRegLoc==1)]] <- AllRegLoc[which(AllRegLoc==1)]
        Data$RegionSize[pi[which(!is.na(Coord$Chromosome))][which(AllRegSize>0)]] <- AllRegSize[which(AllRegSize>0)]
        
        Data$RegionRank[which(Data$RegionPeak == 1)] <- length(which(Data$RegionPeak == 1)) - rank(Data$MedianPR[which(Data$RegionPeak == 1)],ties.method="min")+1
        return(Data)

}


## regionsMPR
## take as main argument a data frame containing the replicated values to average
## other arguments: 
##		threshold applied to the Median Percentile Rank,
##		number of adjacent probes above the threshold to consider enrichments
##		smooth: should the average value be smoothed
##		size and step of the sliding window 
## Return a list containing the data frame with the average value, the MPR vector, the vectors defining the enriched regions and a data frame with the smoothed data

regionsMPR <- function(frame, threshold=0.9, nbProbe=3, Coord=coord)
{
	MeanLogRatio <- apply(frame,1,mean,na.rm=TRUE)
	FrameRank <- apply(frame,2,rank,na.last="keep")
	MedianPR <- apply(FrameRank/length(frame[,1]),1,median,na.rm=TRUE)
	Data <- data.frame(MeanLogRatio=MeanLogRatio, MedianPR=MedianPR)
	Data <- defRegionsMPR(Data, threshold, nbProbe, Coord)	
	return(Data)
}