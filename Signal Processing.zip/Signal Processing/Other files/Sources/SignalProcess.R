##########################################################################################
# Importation of GPR file
##########################################################################################

ImportArray1 <- function (arrayfile,coord)
{
	GPR=read.table(paste("Common/GPR files/",arrayfile,sep=""),skip=31,header=TRUE,as.is=TRUE,sep="\t",quote="\"")
	GPR=GPR[sort(GPR$RefNumber,index.return=TRUE)$ix,]
	coord=coord[sort(coord$RefNumber,index.return=TRUE)$ix,]
	require(TOSCA)
	Array1=import(GPR,colNames=c("F635.Median","B635.Median","F532.Median","B532.Median"),flagVec="Flags",Coord=coord)
	return(Array1)
	}

##########################################################################################
# Ratio Normalization
##########################################################################################

RatioNorm <- function (Array1)
{
	Ratios=sort(Array1$MeanRatio) # Sorting ratios
	l=length(Ratios)
	Ratios=Ratios[1:(0.1*l)] # Saving 10% of lower ratio
	Array1$RatioNorm=Array1$MeanRatio/mean(Ratios,na.rm=TRUE) # Dividing all ratios by the mean of the 10% lowest ratios
	return(Array1)
	}

##########################################################################################
# Suppression of spurious peaks
##########################################################################################

SuppProbe <- function (Array1,coord)
{
	for (i in 1:16)
	{
		P=which(coord$Chromosome==i)
		P=P[sort(coord$Position[P],index.return=TRUE)$ix]
		l=length(P)
		left=right=rep(NA,l)
		left[2:l]=Array1$RatioNorm[P][1:(l-1)]
		right[1:(l-1)]=Array1$RatioNorm[P][2:l]
		Array1$RatioNorm[P][which(Array1$RatioNorm[P]>10 & left<5 & right<5)]=NA
		if (Array1$RatioNorm[P][1]>10 & (Array1$RatioNorm[P][2]<5 | is.na(Array1$RatioNorm[P][2])) & !is.na(Array1$RatioNorm[P][1]))
		{
			Array1$RatioNorm[P][1]=NA
			}
		if (Array1$RatioNorm[P][l]>10 & (Array1$RatioNorm[P][l-1]<5 | is.na(Array1$RatioNorm[P][l-1])) & !is.na(Array1$RatioNorm[P][l]))
		{
			Array1$RatioNorm[P][l]=NA
			}
		}
	return(Array1)
	}

##########################################################################################
# Save NA probes
##########################################################################################

MemorizeNAs <- function (Array1)
{
	Array1$NAs=rep(FALSE,length(Array1$RatioNorm))
	Array1$NAs[which(is.na(Array1$RatioNorm))]=TRUE
	return(Array1)
	}

##########################################################################################
# Replacement of NA probes by mean of their extremities
##########################################################################################

ReplaceNAs <- function (Array1,coord)
{
	for (i in 1:16)
	{
		P=which(coord$Chromosome==i)
		P=P[sort(coord$Position[P],index.return=TRUE)$ix]
		Pos=which(is.na(Array1$RatioNorm[P]))
		j=1
		while (j<=length(Pos))
		{
			k=0
			while (Pos[j+k+1]-Pos[j+k]==1 & !is.na(Pos[j+k+1]))
			{
				k=k+1
				}
			if  (Pos[j]!=1 & Pos[j+k]!=length(P))
			{
				Array1$RatioNorm[P][Pos[j]:Pos[j+k]]=mean(Array1$RatioNorm[P][c((Pos[j]-1),(Pos[j+k]+1))])
				}
			else
			{
				if (Pos[j]==1)
				{
					Array1$RatioNorm[P][Pos[j]:Pos[j+k]]=mean(c(Array1$RatioNorm[P][Pos[j+k]+1],0))
					}
				if (Pos[j+k]==length(P))
				{
					Array1$RatioNorm[P][Pos[j]:Pos[j+k]]=mean(c(Array1$RatioNorm[P][Pos[j]-1],0))
					}
				}
			j=j+k+1
			}
		}
	return(Array1)
	}

##########################################################################################
# Recovering of NA probes
##########################################################################################

RevReplaceNAs <- function (Array1,variable)
{
	Array1[[variable]][which(Array1$NAs)]=NA
	return(Array1)
	}

##########################################################################################
# Denoising of RatioNorm
##########################################################################################

DenoiseRatio <- function (Array1,filter="Daubechies",degree=4,scale=4,thres=2.8,coord,inferior)
{
	Array1$RatioSmooth=rep(NA,length(Array1$RatioNorm))
	
	f=importfilter(filter,degree)
	
	for (i in 1:16)
	{
		P=which(coord$Chromosome==i) # On prend les RefNumbers du chromosome i 
		P=P[sort(coord$Position[P],index.return=TRUE)$ix] # On trie en fonction de la position
		LR=WaveProcess(Array1$RatioNorm[P],scale,thres,f,inferior) # Applying the daubechies wave process to eliminate noise (Denoising step)
		l=LR$d
		Array1$RatioSmooth[P]=LR$s[(l+1):(length(Array1$RatioNorm[P])+l)] # generates a new column called RatioSmooth
		}
	return(Array1)
	}

##########################################################################################
# Second smoothing of RatioSmooth
##########################################################################################

SmoothRatio <- function (Array1,coord,verbose=FALSE,size,variable1,variable2)
{
	require(TOSCA)
	moveWin=movWin(size,coord,verbose)
	Array1=smoothArray(Array1,variable1,coord,moveWin,size,verbose) #Applying the smoothArray function of the TOSCA package to smooth the values, after denoising if denoising=TRUE
	Array1[[variable2]]=Array1$MovAverage
	Array1$MovAverage<-NULL
	Array1$SizeParam<-NULL
	Array1$GridProbe<-NULL
	return(Array1)
	}

##########################################################################################
# Verification of smoothing (graphical function)
##########################################################################################

PdfRatio <- function (array1,name,type,superpose=FALSE,coord,title,centro)
{
	pdf(name,height=21/cm(1),width=29/cm(1))
	par(mfrow=c(3,1))
	max=max(array1$RatioNorm,na.rm=TRUE)
	
	for(i in 1:16)
	{
	m=which(coord$Chro==i)
	m=m[sort(coord$Pos[m],index.return=TRUE)$ix]
	
	plot(coord$Pos[m],array1$RatioNorm[m],col="brown",type=type,lwd=1,ylim=c(1,max),xlab="Chromosome coordinates", ylab=paste(title,"RatioNorm"), cex.main=1.5,las=1,main=paste("chro ",i," brown:RatioNorm, blue: RatioSmooth"))
	if (!is.na(centro[1])[1])
	{
		points(centro[i,1],0.2,pch=19,cex=1,col="green")
		}
	if (superpose)
	{
		par(new=TRUE)
		}
	plot(coord$Pos[m],array1$RatioSmooth[m],col="blue",type=type,lwd=1,xlab="Chromosome coordinates", yaxt="n", ylab=paste(title,"RatioSmooth"), ylim=c(1,max), cex.main=1.5,las=1)
	if (!is.na(centro[1])[1] & !superpose)
	{
		points(centro[i,1],0.2,pch=19,cex=1,col="green")
		}
	axis(4,las=1)
	}
	
	dev.off()
	}

##########################################################################################
# Draws barplots of distributions of RatioSmooth
##########################################################################################

Distrib <- function (Array1,range,name,title)
{
	pdf(name,height=18/cm(1),width=20/cm(1))
	par(mfrow=c(1,1))
	
	ratios=Array1$RatioSmooth[which(!is.na(Array1$RatioSmooth) & Array1$RatioSmooth>0)]
	ratios=log(ratios,base=2)
	occurences=rep(NA,range)
	labels=rep("",range)
	step=(max(ratios)-min(ratios))/range
	for (i in 1:range)
	{
		boundary1=min(ratios)+(i-1)*step
		boundary2=min(ratios)+i*step
		occurences[i]=length(which(ratios>boundary1 & ratios<=boundary2))
		if (i%%(range/10)==0 || i==1)
		{
			labels[i]=paste((round(boundary1,digits=2)),"-",round(boundary2,digits=2),sep="")
			}
		}
	barplot(occurences,names.arg=labels,col=colorRampPalette(c("blue","yellow","red"),space="Lab")(length(occurences)),cex.names=0.7,cex.axis=0.7,las=3,main=paste("Distribution of log2(RatioSmooth) from ",title,sep=""),ylab="Occurences",cex.main=1,cex.sub=0.8,cex.lab=0.8,sub="log2(RatioSmooth)")
	mtext(paste("mean = ",round(mean(ratios),digits=3),sep=""),side=3)
	
	dev.off()
	}

##########################################################################################
# Draws barplots of distributions of Peaks of RatioSmooth (before finding peaks)
##########################################################################################

DistribPeaks <- function (Array1,coord,range,name,title)
{
	pdf(name,height=18/cm(1),width=20/cm(1))
	par(mfrow=c(1,1))
	
	ratios=rep(NA,length(Array1$RatioSmooth))
	
	for (i in 1:16)
	{
		P=which(coord$Chromosome==i)
		P=P[sort(coord$Position[P],index.return=TRUE)$ix]
		Left=Right=Left2=Right2=rep(NA,length(P))
		Left[2:length(P)]=Array1$RatioSmooth[P][2:length(P)]-Array1$RatioSmooth[P][1:(length(P)-1)]
		Right[1:(length(P)-1)]=Array1$RatioSmooth[P][1:(length(P)-1)]-Array1$RatioSmooth[P][2:length(P)]
		Left2[3:length(P)]=Left[2:(length(P)-1)]
		Right2[1:(length(P)-2)]=Right[2:(length(P)-1)]
		ratios[P][which(Left>0 & Right>0)]=Array1$RatioSmooth[P][which(Left>0 & Right>0)]
		ratios[P][which((Left==0 & Left2>0 & Right>0) | (Right==0 & Right2>0 & Left>0))]=Array1$RatioSmooth[P][which((Left==0 & Left2>0 & Right>0) | (Right==0 & Right2>0 & Left>0))]
		}
	
	ratios=ratios[which(!is.na(ratios) & ratios>1.5)]
	ratios=log(ratios,base=2)
	occurences=rep(NA,range)
	labels=rep("",range)
	step=(max(ratios)-min(ratios))/range
	for (i in 1:range)
	{
		boundary1=min(ratios)+(i-1)*step
		boundary2=min(ratios)+i*step
		occurences[i]=length(which(ratios>boundary1 & ratios<=boundary2))
		if (i%%(range/10)==0 || i==1)
		{
			labels[i]=paste((round(boundary1,digits=2)),"-",round(boundary2,digits=2),sep="")
			}
		}
	barplot(occurences,names.arg=labels,col=colorRampPalette(c("blue","yellow","red"),space="Lab")(length(occurences)),cex.names=0.7,cex.axis=0.7,las=3,main=paste("Distribution of local maxima of log2(RatioSmooth) from ",title,sep=""),ylab="Occurences",cex.main=1,cex.sub=0.8,cex.lab=0.8,sub="log2(RatioSmooth)")
	mtext(paste("mean = ",round(mean(ratios),digits=3),sep=""),side=3)
	
	dev.off()
	}

##########################################################################################
# Returns the mean of maxima
##########################################################################################

MeanMax <- function (Array1,coord,threshold)
{
	Max=rep(NA,length(Array1$RatioSmooth))
	for (i in 1:16)
	{
		P=which(coord$Chromosome==i)
		P=P[sort(coord$Position[P],index.return=TRUE)$ix]
		Left=Right=Left2=Right2=rep(NA,length(P))
		Left[2:length(P)]=Array1$RatioSmooth[P][2:length(P)]-Array1$RatioSmooth[P][1:(length(P)-1)]
		Right[1:(length(P)-1)]=Array1$RatioSmooth[P][1:(length(P)-1)]-Array1$RatioSmooth[P][2:length(P)]
		Left2[3:length(P)]=Left[2:(length(P)-1)]
		Right2[1:(length(P)-2)]=Right[2:(length(P)-1)]
		Max[P][which(Left>0 & Right>0)]=Array1$RatioSmooth[P][which(Left>0 & Right>0)]
		Max[P][which(((Left==0 & Left2>0 & Right>0) | (Right==0 & Right2>0 & Left>0)) & Array1$RatioSmooth[P]>1.5)]=Array1$RatioSmooth[P][which(((Left==0 & Left2>0 & Right>0) | (Right==0 & Right2>0 & Left>0)) & Array1$RatioSmooth[P]>1.5)]
		}
	Max=sort(Max)
	Meanmax=threshold*mean(Max[1:(0.45*length(Max))]) # We multiply the threshold value by the 45% weakest local maxima, and use this number as the new threshold value to find peaks
	
	return(Meanmax)
	}

##########################################################################################
# Find peaks after smoothing
##########################################################################################

FindPeaks <- function (Array1,thres,coord,force_threshold)
{
	if (!force_threshold)
	{
		if (thres<1.5)
		{
			thres=1.5
			}
		}
	Array1$Peaks=Array1$Sites=rep(NA,length(Array1$RatioSmooth))
	#Array1$PeakLeft=rep(NA,length(Array1$RatioSmooth))
	
	for (i in 1:16)
	{
		P=which(coord$Chromosome==i)
		P=P[sort(coord$Position[P],index.return=TRUE)$ix]
		
		Left=Right=Left2=Right2=PeakCor=rep(NA,length(P))
		Left[2:length(P)]=Array1$RatioSmooth[P][2:length(P)]-Array1$RatioSmooth[P][1:(length(P)-1)] # 
		Right[1:(length(P)-1)]=Array1$RatioSmooth[P][1:(length(P)-1)]-Array1$RatioSmooth[P][2:length(P)]
		Left2[3:length(P)]=Left[2:(length(P)-1)]
		Right2[1:(length(P)-2)]=Right[2:(length(P)-1)]
		Posmaxi=which(Left>0 & Right>0) # Positions of local maximums
		Posmaxi2=which((Left==0 & Left2>0 & Right>0) | (Right==0 & Right2>0 & Left>0))
		Posmaxi=append(Posmaxi,Posmaxi2)
		Posmaxi=sort(Posmaxi)
		Posmini=which(Left<0 & Right<0) # Positions of local minimums, 
		Posmini2=which((Left==0 & Left2<0 & Right<0) | (Right==0 & Right2<0 & Left<0))
		Posmini=append(Posmini,Posmini2)
		Posmini=sort(Posmini)
		Array1$Peaks[P][Posmaxi][which(Array1$RatioSmooth[P][Posmaxi]>thres)]=1 # Puts 1 on the position of peaks which are at maximum local positions and > threshold
		
		Pos=which(Array1$Peaks[P]==1) # Positions of the peaks
		FollowPos=rep(NA,length(Pos))
		FollowPos[1:(length(Pos)-1)]=Pos[2:length(Pos)]-Pos[1:(length(Pos)-1)] # We look the next peak positions (differences)
		Pos2=Pos[which(FollowPos<=3)] # If the next peak is less than 3 probes next
		FollowPos2=Pos2+FollowPos[which(FollowPos<=3)] # We take the absolute positions (and not the differences)
		Pmin=pmin(Array1$RatioSmooth[P][Pos2],Array1$RatioSmooth[P][FollowPos2]) # We look at the minima peaks
		Posmin=Pos2[which(Array1$RatioSmooth[P][Pos2]==Pmin & Array1$RatioSmooth[P][Pos2]!=Array1$RatioSmooth[P][FollowPos2])]
		Posmin=append(Posmin,FollowPos2[which(Array1$RatioSmooth[P][FollowPos2]==Pmin & Array1$RatioSmooth[P][Pos2]!=Array1$RatioSmooth[P][FollowPos2])])
		Posmin=sort(Posmin)
		Pmax=pmax(Array1$RatioSmooth[P][Pos2],Array1$RatioSmooth[P][FollowPos2])
		Posmax=Pos2[which(Array1$RatioSmooth[P][Pos2]==Pmax)]
		Posmax=append(Posmax,FollowPos2[which(Array1$RatioSmooth[P][FollowPos2]==Pmax)])
		Posmax=sort(Posmax)
		donotcorrect=rep(NA,length(P))
		PeakCor=Array1$Peaks[P] # Recuperation of Peaks in PeakCor
		PeakCor[Posmin]=NA # Deleting local minimums in PeakCor
		donotcorrect[Posmax][which(PeakCor[Posmax]==1)]=1
		#Array1$PeakCor[P]=Array1$Peaks[P] # If the line is no comment, it recuperates the local minimums in Peaks
		Array1$Peaks[P][which(is.na(PeakCor))]=NA # Applying PeakCor local minimums deleting to the whole Peaks list
		
		Pos=Posmaxi[which(Array1$Peaks[P][Posmaxi]==1)]
		FollowPos=rep(NA,length(Pos))
		FollowPos[1:(length(Pos)-1)]=Pos[2:length(Pos)]-Pos[1:(length(Pos)-1)]
		distances=rep(NA,length(Pos))
		for (j in 1:length(distances))
		{
			distances[j]=min(abs(Posmini-Pos[j]))
			}
		Pos=Pos[which(distances<=1)]
		Array1$Peaks[P][Pos][which(is.na(donotcorrect[Pos]))]=NA
		
		Pos=which(Array1$Peaks[P]==1) 
		FollowPos=rep(NA,length(Pos))
		FollowPos[1:(length(Pos)-1)]=Pos[2:length(Pos)]-Pos[1:(length(Pos)-1)]
		Pos2=Pos[which(FollowPos==1)]
		FollowPos2=Pos2+FollowPos[which(FollowPos==1)]
		Pos=coord$Pos[P][Pos2]
		FollowPos=coord$Pos[P][FollowPos2]
		Array1$Sites[P][Pos2]=apply(data.frame(Pos,FollowPos),1,mean)
		
		Pos=which(Array1$Peaks[P]==1)
		#Array1$PeakLeft[P][Pos][2:length(Pos)]=Pos[2:length(Pos)]-Pos[1:(length(Pos)-1)] # Bug taille des tableaux lorsqu'on utilise un threshold plus grand que 1.56
		}
	
	message("\nNumber of sites: ",length(which(Array1$Peaks==1))-length(which(Array1$Sites>0)),"\nThreshold used: ",thres,"\n",sep="")
	
	return(Array1)
	}

##########################################################################################
# Find peaks after no smoothing (This step occurs when we do no smoothing, smooth=0 in Main)
##########################################################################################

FindPeaks2 <- function (Array1,threshold,coord)
{
	Max=max(Array1$RatioSmooth,na.rm=TRUE)
	thres=c(threshold[1],threshold[2])
	thres[1]=MeanMax(Array1,coord,threshold[1])
	thres[2]=MeanMax(Array1,coord,threshold[2])
	message(paste("\n1st threshold: ",thres[1],"\n2nd threshold: ",thres[2],sep=""))
	thres[3]=threshold[3]
	Array1$Peaks=PeakCor=rep(NA,length(Array1$RatioNorm))
	Peakmin=Peakmax=Peakmean=rep(NA,16)
	Array1$PeakLeft=rep(NA,length(Array1$RatioSmooth))

	for(i in 1:16)
	{
		P=which(coord$Chromosome==i)
		P=P[sort(coord$Position[P],index.return=TRUE)$ix]
		Left=Right=rep(NA,length(P))
		
		Left[2:length(P)]=Array1$RatioSmooth[P][2:length(P)]-Array1$RatioSmooth[P][1:(length(P)-1)]
		Right[1:(length(P)-1)]=Array1$RatioSmooth[P][1:(length(P)-1)]-Array1$RatioSmooth[P][2:length(P)]
		
		PosMaxi=which((Left>0 | is.na(Left)) & (Right>0 | is.na(Right)))
		PosMini=which((Left<0 | is.na(Left)) & (Right<0 | is.na(Right)))
		sing=append(PosMini,PosMaxi)
		sing=sort(sing)
		
		Left=Right=rep(NA,length(sing))
		
		Left[2:length(sing)]=Array1$RatioSmooth[P][sing[2:length(sing)]]-Array1$RatioSmooth[P][sing[1:(length(sing)-1)]]
		Right[1:(length(sing)-1)]=Array1$RatioSmooth[P][sing[1:(length(sing)-1)]]-Array1$RatioSmooth[P][sing[2:length(sing)]]
		Array1$Peaks[P][sing[which(Left>thres[1] & Right>thres[1] & Array1$RatioSmooth[P][sing]>thres[2])]]=1
		
		Pos=which(((Left>thres[1] | Right>thres[1]) & Array1$RatioSmooth[P][sing]>thres[2]))
		Pos=sing[Pos]
		PeakCor[P][Pos]=1
		
		FollowPos=FollowPos2=rep(NA,length(Pos))
		FollowPos[1:(length(Pos)-1)]=Pos[2:length(Pos)]-Pos[1:(length(Pos)-1)]
		FollowPos2[1:(length(Pos)-1)]=coord$Pos[P][Pos][2:length(Pos)]-coord$Pos[P][Pos][1:(length(Pos)-1)]
		Pos=Pos[which(FollowPos2<=thres[3])]
		FollowPos=FollowPos[which(FollowPos2<=thres[3])]
		FollowPos=Pos+FollowPos
		Pos2=Pos[which(abs(Array1$RatioSmooth[P][Pos]-Array1$RatioSmooth[P][FollowPos])>thres[1])]
		FollowPos2=FollowPos[which(abs(Array1$RatioSmooth[P][Pos]-Array1$RatioSmooth[P][FollowPos])>thres[1])]
		
		Pmin=pmin(Array1$RatioSmooth[P][Pos2],Array1$RatioSmooth[P][FollowPos2],na.rm=TRUE)
		Posmin=Pos2[which(Array1$RatioSmooth[P][Pos2]==Pmin)]
		Posmin=append(Posmin,FollowPos2[which(Array1$RatioSmooth[P][FollowPos2]==Pmin)])
		Posmin=sort(Posmin)
		PeakCor[P][Posmin]=NA
		
		Array1$Peaks[P][which(PeakCor[P]==1)]=1
		
		PosPeaks=coord$Pos[P][which(Array1$Peaks[P]==1)]
		Array1$PeakLeft[P][2:length(PosPeaks)]=PosPeaks[2:length(PosPeaks)]-PosPeaks[1:(length(PosPeaks)-1)]
		Peakmin[i]=min(Array1$PeakLeft[P],na.rm=TRUE)
		Peakmax[i]=max(Array1$PeakLeft[P],na.rm=TRUE)
		Peakmean[i]=mean(Array1$PeakLeft[P],na.rm=TRUE)
		}
	
	message(paste("\nNumber of sites: ",length(which(Array1$Peaks==1))-SitePeaks(Array1,coord,thres[3]),"\nNumber of peaks: ",length(which(Array1$Peaks==1)),"\nDistances of Peaks (in bp):\n-Minimum: ",min(Peakmin,na.rm=TRUE),"\n-Maximum: ",max(Peakmax,na.rm=TRUE),"\n-Mean: ",mean(Peakmean,na.rm=TRUE),"\n",sep=""))
	return(Array1)
	}

##########################################################################################
# Returns the number of peaks with a distance inferior to sitethreshold (function used by FindPeaks2, only if smooth=0 in Main)
##########################################################################################

SitePeaks <- function (Array1,coord,sitethreshold)
{
	numbers=rep(NA,16)
	for (i in 1:16)
	{
		P=which(coord$Chromosome==i)
		P=P[sort(coord$Position[P],index.return=TRUE)$ix]
		
		Pos=which(Array1$Peaks[P]==1)
		FollowPos=rep(NA,length(Pos))
		FollowPos[1:(length(Pos)-1)]=coord$Pos[P[Pos[2:length(Pos)]]]-coord$Pos[P[Pos[1:(length(Pos)-1)]]]
		numbers[i]=length(which(FollowPos<=sitethreshold))
		}
	numbers=sum(numbers)
	
	return (numbers)
	}

##########################################################################################
# Draws occurences of distances between peaks on a barplots
##########################################################################################

PeakDist <- function (Array1,name,coord,title,range)
{
	pdf(name,height=18/cm(1),width=20/cm(1))
	par(mfrow=c(1,1))
	
	peakmean=rep(NA,16)
	distances=rep(NA,length(Array1$RatioNorm))
	for (i in 1:16)
	{
		P=which(coord$Chromosome==i)
		P=P[sort(coord$Position[P],index.return=TRUE)$ix]
		Pos=which(Array1$Peaks[P]==1&is.na(Array1$Sites[P]))
		Pos1=coord$Pos[P][which(Array1$Peaks[P]==1&is.na(Array1$Sites[P]))]
		Pos2=rep(NA,length(Pos1))
		Pos2[1:(length(Pos2)-1)]=Pos1[2:length(Pos2)]
		distances[P][Pos]=abs(Pos2-Pos1)
		peakmean[i]=mean(distances[P],na.rm=TRUE)
		}
	
	distances=distances[which(!is.na(distances))]
	occurences=rep(NA,range)
	labels=rep("",range)
	for (i in 1:range)
	{
		occurences[i]=length(which(distances>=round((i-1)*(max(distances)/range)) & distances<round(i*(max(distances)/range))))
		if (i%%(range/20)==0 || i==1)
		{
			labels[i]=paste(round((i-1)*(max(distances)/range)/1000),"-",round(i*(max(distances)/range)/1000),sep="")
			}
		}
	barplot(occurences,names.arg=labels,col=colorRampPalette(c("red","yellow","blue"),space="Lab")(length(occurences)),cex.names=0.7,cex.axis=0.7,las=3,main=paste("Distribution of distances of peaks from ",title,sep=""),xlab="Distance ranges (in kb)",ylab="Occurences",sub=paste("mean = ",round(mean(peakmean)/1000,digits=3)," kb",sep=""),cex.main=1,cex.sub=0.7,cex.lab=0.8)
	
	dev.off()
	}

##########################################################################################
# Peaks Orders
##########################################################################################

PeakOrders <- function (Array1,coord)

{
	Array1$PeakOrders=rep(NA,length(Array1$RatioSmooth))
	Array1$PeakOrders[which(Array1$Peaks==1 & !is.na(Array1$RatioSmooth))]=(length(which(Array1$Peaks==1))-rank(Array1$RatioSmooth[which(Array1$Peaks==1 & !is.na(Array1$RatioSmooth))],na.last="keep"))+1
	return(Array1)
	}

##########################################################################################
# Verification of peaks
##########################################################################################

PdfPeaks <- function (array1,name,coord,title,thres,centro)
{
	pdf(name,height=21/cm(1),width=29/cm(1))
	par(mfrow=c(3,1))
	Max=max(array1$RatioSmooth,na.rm=TRUE)

	for(i in 1:16)
	{
		m=which(coord$Chro==i)
		m=m[sort(coord$Pos[m],index.return=TRUE)$ix]
		
		plot(coord$Pos[m],array1$RatioSmooth[m],col="brown",type="l",lwd=1,ylim=c(1,Max),xlab="Chromosome coordinates", ylab=paste(title,"Ratio Smooth"), cex.main=1.5,las=1,main=paste("chro ",i," ",title))
		points(coord$Pos[m[which(array1$Peaks[m]==1)]],array1$RatioSmooth[m[which(array1$Peaks[m]==1)]],col="brown",pch=20,cex=1.2)
		abline(h=thres,col="grey")
		if (!is.na(centro[1])[1])
		{
			points(centro[i,1],0.2,pch=19,cex=1,col="green")
			}
		}

	dev.off()
	}

##########################################################################################
# Data signal process
##########################################################################################

DataSignalProcess <- function (coordfile,centrofile,arrayfile,scale,thres,SuppPeaks=TRUE,superpose=FALSE,RecoverNA=TRUE,type,threshold,name,range,size,smooth,threshold2,range2,movwin,Denoising,force_threshold)

{
	if (name=="")
	{
		name=paste(substr(arrayfile,1,nchar(arrayfile)-4),"_Processed",sep="")
		}
	else
	{
		name=paste(name,"_Processed",sep="")
		}
	
	message("Importation of coord file...")
	coord=read.table(paste("Common/Coord files/",coordfile,sep=""))
	if (centrofile=="")
	{
		centro=NA
		}
	else
	{
		centro=read.table(paste("Common/Coord files/",centrofile,sep=""))
		}
	
	message("Importation of data files...")
	l=nchar(arrayfile[1])
	if (substr(arrayfile[1],l-3,l)==".gpr")
	{
		Array1=list()
		for (i in 1:length(arrayfile))
		{
			Array=ImportArray1(arrayfile[i],coord)
			Array1[[paste("Ratio",i,sep="")]]=Array$Ratio
			Chromosome=Array$Chromosome
			Position=Array$Position
			}
		Array1=as.data.frame(Array1)
		Array1$MeanRatio=apply(Array1,1,mean)
		Array1$Chromosome=Chromosome
		Array1$Position=Position
		}
	if (substr(arrayfile[1],l-3,l)==".txt")
	{
		if (length(arrayfile)>1)
		{
			warning("You can't use more than 1 table file")
			stop()
			}
		Array1=read.table(paste("Common/Table files/",arrayfile[1],sep=""))
		if (length(Array1$MeanRatio)==0)
		{
			Array1$MeanRatio=Array1$Ratio
			}
		}
	
		message("Normalization...")
		Array1=RatioNorm(Array1)
	
	if (SuppPeaks)
	{
		message("Suppression of isolated peaks...")
		Array1=SuppProbe(Array1,coord)
		}
	
	if (RecoverNA)
	{
		message("Memorization of NA probes...")
		Array1=MemorizeNAs(Array1)
		}
	
	message("Replacement of NA probes...")
	Array1=ReplaceNAs(Array1,coord)
	
	if (Denoising) # Call the denoising function
	{
		message("Denoising...")
		Array1=DenoiseRatio(Array1,filter="Daubechies",degree=4,scale=scale,thres=thres,coord,inferior=TRUE)
		Array1$RatioDenoised=Array1$RatioSmooth #RatioDenoised is never used
		}
	else # If no denoising step, this first RatioSmooth=RatioNorm because the denoising function use rationorm to provide ratiosmooth for the other processing steps
	{
		Array1$RatioSmooth=rep(NA,length(Array1$RatioNorm))
		for (i in 1:16)
		{
			P=which(coord$Chromosome==i) # On prend les RefNumbers du chromosome i 
			P=P[sort(coord$Position[P],index.return=TRUE)$ix] # On trie en fonction de la position
			Array1$RatioSmooth[P]=Array1$RatioNorm[P]
			}
		}
	
	if (smooth>0)
	{
		message("Smoothing...")
		peaks2=FALSE
		for (i in 1:smooth)
		{
			if (i==1)
			{
				variable1="RatioSmooth"
				}
			else
			{
				variable1=paste("RatioSmoothed",i-1,sep="")
				}
			Array1=SmoothRatio(Array1,coord,FALSE,movwin,variable1,paste("RatioSmoothed",i,sep=""))
			message(paste(i/smooth*100,"%",sep=""))
			}
		Array1$RatioSmooth=Array1[[paste("RatioSmoothed",smooth,sep="")]]
		}
	
	else
	{
		peaks2=TRUE
		}
	
	message("Finding peaks...")
	if (peaks2)
	{
		Array1=FindPeaks2(Array1,threshold2,coord)
		}
	else
	{
		if(force_threshold) # If threshold is forced, FindPeaks don't use MeanMax but the threshold you entered
		{
			message(paste("Processing with forced threshold : ",threshold,sep=""))
			thres=threshold # Used thres takes the value of the imposed threshold
			}
		else
		{
			thres=MeanMax(Array1,coord,threshold) # If smooth > 0 and threshold is automatic
			}
		Array1=FindPeaks(Array1,thres,coord,force_threshold)
		}
	Array1=PeakOrders(Array1,coord)
	
		if (RecoverNA)
	{
		message("Recovering of NA probes...")
		Array1=RevReplaceNAs(Array1,"RatioNorm")
		Array1=RevReplaceNAs(Array1,"RatioSmooth")
		}
	
	#unlink(paste("Signal Processing/Saved files/PDF files/",name,sep=""),recursive=TRUE)
	dir.create(paste("Signal Processing/Saved files/PDF files/",name,sep=""))
	
	message("Saving graphs for verification of denoising...")
	PdfRatio(Array1,paste("Signal Processing/Saved files/PDF files/",name,"/Denoising.pdf",sep=""),type=type,superpose=superpose,coord,name,centro)
	
	message("Saving graphs for verification of peaks...")
	PdfPeaks(Array1,paste("Signal Processing/Saved files/PDF files/",name,"/Peaks.pdf",sep=""),coord,name,thres,centro)
	
	message("Saving barplots...")
	PeakDist(Array1,paste("Signal Processing/Saved files/PDF files/",name,"/Distance of peaks.pdf",sep=""),coord,substr(name,1,(nchar(name)-10)),range)
	Distrib(Array1,range2,paste("Signal Processing/Saved files/PDF files/",name,"/Distribution of Ratios.pdf",sep=""),substr(name,1,(nchar(name)-10)))
	DistribPeaks(Array1,coord,range2,paste("Signal Processing/Saved files/PDF files/",name,"/Distribution of local maxima.pdf",sep=""),substr(name,1,(nchar(name)-10)))
	
	message("Saving table file...")
	if (!(Denoising)) # If we process without denoising step, ratiosmooth is renamed
	{
		Array1$RatioSmooth_noDenoise=Array1$RatioSmooth
		Array1$RatioSmooth=NULL
		}
	write.table(Array1,paste("Signal Processing/Saved files/Processed table files/",name,".txt",sep=""))
	
	message("Processing finished")
	return(list(Array1=Array1,coord=coord))
	}