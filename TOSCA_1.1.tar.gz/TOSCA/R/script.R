script <- function(rawData, flagVec=NULL, size=1000, variable="LRMC",  verbose=TRUE, ExpectedFDR=0.1, nbPerm=30, method="All")
{
	if(verbose)cat("start\n") 
		Data <- import(rawData,flagVec)
		
		Data <- smoothArray(Data,variable="LRMC", size, verbose)

		if(method=="All" | method=="FDR")
		{
			Data <- regionsFDR(Data, variable, ExpectedFDR, nbPerm, verbose)
			reportQC(Data, variable)
		}
		if(method=="All")
		{
			Data2 <- regionsGaussian(Data, variable, verbose)
			reportQC(Data2,  variable)
		}
		if(method=="Gaussian")
		{
			Data <- regionsGaussian(Data, variable, verbose)
			reportQC(Data,  variable)
		}
		
		
		if(verbose)cat(file,": done at",date(),"\n")
			
			if(method=="All")return(list(Data=Data,Data2=Data2))
				else return(Data)
					
}
