## plot a profile around a feature (start of the genes, for instance).
## Relative coordinates must be indicated in relPos (calculated by DistToFeatures)
## subset permit to consider only a subset of the probes


plotPseudoGene <- function(Data, relPos, subset=NULL, step=50, variable="LRMC", relPosMin=-1000, relPosMax=2000)
  {
	pseudoProfile=NULL
        if(is.null(subset))subset=c(1:length(relPos))
    mseq=seq(relPosMin,relPosMax,by=2*step)
    for(i in 1:length(mseq))
      {
        p=subset[which(relPos[subset] > mseq[i]-step & relPos[subset] < mseq[i]+step)]
        pseudoProfile[i]=mean(Data[[variable]][p],na.rm=TRUE)
      }

        plot(mseq,pseudoProfile,type="l",main="Relative Profile",xlab="",ylab="")
        abline(h=0,lty=2)
        abline(v=0,lty=2)

  }
