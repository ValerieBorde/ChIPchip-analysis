
## Import a gpr file, normalize the logratio and return a data.frame
## Default columns names are F635.Median, F532.Median, B635.Median and B532.Median
## Use the background-substracted intensities
## Normalization:
## If variable=LRMC (for LogRatioMedianCentered): substract the median of the logratio distribution
## If variable=LRNormC: substract the median and divide by the standard deviation

importGPR <- function(file, myskip=0, Fip="F635.Median", Ftotal="F532.Median", Bip="B635.Median", Btotal="B532.Median", DyeSwap=FALSE, flagVec=NULL, Coord=coord)
{
    rawData <- read.table(file, header=TRUE, as.is=TRUE, sep="\t", quote="\"", skip=myskip)
	if(length(rawData$RefNumber) == length(rawData[,1])) rawData <- rawData[sort(rawData$RefNumber, index.return=TRUE)$ix,]

    lengthData <- length(rawData[,1])

    ## is considered as bad:
    ## spots flagged in the datafile
    if(!is.null(flagVec))flags <- which(rawData[[flagVec]] != 0)
	
	
    FBip <- rep(NA, lengthData)
    FBtotal <- rep(NA, lengthData)
     if(!is.null(flagVec)){
		  if(!is.null(rawData[[Bip]]) & !is.null(rawData[[Btotal]]))
		{
			FBip[-flags] <- rawData[[Fip]][-flags] - rawData[[Bip]][-flags]
			FBtotal[-flags] <- rawData[[Ftotal]][-flags] - rawData[[Btotal]][-flags]
		}
		if(is.null(rawData[[Bip]]) | is.null(rawData[[Btotal]]))
		{
			FBip[-flags] <- rawData[[Fip]][-flags]
			FBtotal[-flags] <- rawData[[Ftotal]][-flags]
		}
	}
	else 
	{
		  if(!is.null(rawData[[Bip]]) & !is.null(rawData[[Btotal]]))
		{
			FBip <- rawData[[Fip]] - rawData[[Bip]]
			FBtotal <- rawData[[Ftotal]] - rawData[[Btotal]]
		}
		if(is.null(rawData[[Bip]]) | is.null(rawData[[Btotal]]))
		{
			FBip <- rawData[[Fip]]
			FBtotal <- rawData[[Ftotal]]
		}
		
	}

    FBip[which(FBip == 0)] <- NA
    FBtotal[which(FBtotal == 0)] <- NA

    if(!DyeSwap) Ratio <- FBip/FBtotal
	else Ratio <- FBtotal/FBip
    LogRatio <- log2(Ratio)
    LogRatioMedianCentered <- (LogRatio-median(LogRatio, na.rm=TRUE))
    LogRatioNormCentr <- (LogRatio-median(LogRatio, na.rm=TRUE))/sd(LogRatio, na.rm=TRUE)

    Data <- data.frame(FBip, FBtotal, Ratio, LogRatio, LRMC=LogRatioMedianCentered, LRNorm=LogRatioNormCentr, Chromosome=Coord$Chromosome, Position=Coord$Position)
    return(Data)
}

import <- function(rawData, colNames=NULL, flagVec=NULL, Coord=coord)
{
	if(!is.null(colNames)){
		for(i in 1:length(colNames))
		{
		if(is.na(match(colNames[i], names(rawData))))stop(paste("Error:\n", colNames[i], " does not correspond to a valid column names"))
		}
	}
	if(!is.null(flagVec)) 
	{
		if(is.na(match(flagVec, names(rawData)))) stop(paste("Error:\n", colNames[i], " does not correspond to a valid column names"))
		else flags=which(rawData[[flagVec]] != 0)
	}

	if(length(colNames) == 2)
	{
		FBip <- FBtotal <- rep(NA, length(rawData[,1]))
		if(!is.null(flagVec)) 
		{
			FBip[-flags] <- rawData[[colNames[1]]][-flags]
			FBtotal[-flags] <- rawData[[colNames[2]]][-flags]
		}
		else {
			FBip <- rawData[[colNames[1]]]
			FBtotal <- rawData[[colNames[2]]]
		}
	    
		FBip[which(FBip == 0)] <- NA
		FBtotal[which(FBtotal == 0)] <- NA
		Ratio <- FBip/FBtotal
		LogRatio <- log2(Ratio)
		LogRatioMedianCentered <- (LogRatio-median(LogRatio, na.rm=TRUE))
		LogRatioNormCentr <- (LogRatio-median(LogRatio, na.rm=TRUE))/sd(LogRatio, na.rm=TRUE)

		Data <- data.frame(FBip, FBtotal, Ratio, LogRatio, LRMC=LogRatioMedianCentered, LRNorm=LogRatioNormCentr, Chromosome=Coord$Chromosome, Position=Coord$Position)
		return(Data)	
	}
	
	if(length(colNames) == 4)
	{
		FBip <- FBtotal <- rep(NA, length(rawData[,1]))		
		if(!is.null(flagVec)) 
		{
			FBip[-flags] <- rawData[[colNames[1]]][-flags]-rawData[[colNames[2]]][-flags]
			FBtotal[-flags] <- rawData[[colNames[3]]][-flags]-rawData[[colNames[4]]][-flags]
		}
		else {
			FBip <- rawData[[colNames[1]]]-rawData[[colNames[2]]]
			FBtotal <- rawData[[colNames[3]]]-rawData[[colNames[4]]]		
			}
		
		FBip[which(FBip == 0)] <- NA
		FBtotal[which(FBtotal == 0)] <- NA
		Ratio <- FBip/FBtotal
		LogRatio <- log2(Ratio)
		LogRatioMedianCentered <- (LogRatio-median(LogRatio, na.rm=TRUE))
		LogRatioNormCentr <- (LogRatio-median(LogRatio, na.rm=TRUE))/sd(LogRatio, na.rm=TRUE)

		Data <- data.frame(FBip, FBtotal, Ratio, LogRatio, LRMC=LogRatioMedianCentered, LRNorm=LogRatioNormCentr, Chromosome=Coord$Chromosome, Position=Coord$Position)
		return(Data)	
	}
	
	if(is.null(colNames))
	{
		if(length(which(!is.na(match(names(rawData),c("LogRatio","logratio","Logratio","Log.Ratio..635.532.")))))>0)
		{
			LogRatio <- rep(NA, length(rawData[,1]))

			if(!is.null(flagVec)) LogRatio[-flags] <- rawData[-flags, which(!is.na(match(names(rawData),c("LogRatio","logratio","Logratio","Log.Ratio..635.532."))))]
			else LogRatio <- rawData[, which(!is.na(match(names(rawData),c("LogRatio","logratio","Logratio","Log.Ratio..635.532."))))]
			LogRatioMedianCentered <- (LogRatio-median(LogRatio, na.rm=TRUE))
			LogRatioNormCentr <- (LogRatio-median(LogRatio, na.rm=TRUE))/sd(LogRatio, na.rm=TRUE)
			Data <- data.frame(LogRatio, LRMC=LogRatioMedianCentered, LRNorm=LogRatioNormCentr, Chromosome=Coord$Chromosome, Position=Coord$Position)
			return(Data)
		}
		
		if(length(which(!is.na(match(names(rawData),c("Ratio","ratio","RATIO")))))>0)
		{
			Ratio <- rep(NA,length(rawData[,1]))
			if(!is.null(flagVec)) Ratio[-flags] <- rawData[-flags, match(names(rawData),c("Ratio","ratio","RATIO"))]			else Ratio <- rawData[, match(names(rawData),c("Ratio","ratio","RATIO"))]
			LogRatio <- log2(Ratio)
			LogRatioMedianCentered <- (LogRatio-median(LogRatio, na.rm=TRUE))
			LogRatioNormCentr <- (LogRatio-median(LogRatio, na.rm=TRUE))/sd(LogRatio, na.rm=TRUE)
			Data <- data.frame(Ratio, LogRatio, LRMC=LogRatioMedianCentered, LRNorm=LogRatioNormCentr, Chromosome=Coord$Chromosome, Position=Coord$Position)
			return(Data)
		}
	}
	
	if(length(colNames) == 1)
	{
		if(colNames %in% c("LogRatio","logratio","Logratio","Log Ratio") | regexpr("[lL]og *[rR]atio",colNames)[1]==1)
		{
			LogRatio <- rep(NA, length(rawData[,1]))
			if(!is.null(flagVec)) LogRatio[-flags] <- rawData[[colNames]][-flags]
			else LogRatio <- rawData[[colNames]]
			LogRatioMedianCentered <- (LogRatio-median(LogRatio, na.rm=TRUE))
			LogRatioNormCentr <- (LogRatio-median(LogRatio, na.rm=TRUE))/sd(LogRatio, na.rm=TRUE)
			Data <- data.frame(LogRatio, LRMC=LogRatioMedianCentered, LRNorm=LogRatioNormCentr, Chromosome=Coord$Chromosome, Position=Coord$Position)
			return(Data)
		}
		
		if(colNames %in% c("Ratio","ratio","RATIO")) 
		{
			Ratio <- rep(NA,length(rawData[,1]))
			if(!is.null(flagVec)) Ratio[-flags] <- rawData[[colNames]][-flags]
			else Ratio <- rawData[[colNames]]
			LogRatio <- log2(Ratio)
			LogRatioMedianCentered <- (LogRatio-median(LogRatio, na.rm=TRUE))
			LogRatioNormCentr <- (LogRatio-median(LogRatio, na.rm=TRUE))/sd(LogRatio, na.rm=TRUE)
			Data <- data.frame(Ratio, LogRatio, LRMC=LogRatioMedianCentered, LRNorm=LogRatioNormCentr, Chromosome=Coord$Chromosome, Position=Coord$Position)
			return(Data)
		}
	}
	 
    
	
}
